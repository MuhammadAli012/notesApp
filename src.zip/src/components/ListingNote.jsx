import React, { useState, useEffect } from 'react'

import { XCircle } from 'react-bootstrap-icons';
import { ArrowRightCircleFill } from 'react-bootstrap-icons';
import { TrashFill } from 'react-bootstrap-icons'
import { useNavigate } from 'react-router-dom'
import { PlusLg, PencilSquare } from 'react-bootstrap-icons'




export const ListingNote = () => {
    const navigate = useNavigate();
    return (
        <>
            <div className='col-md-12'>
                <nav className="navbar bg-body-tertiary">
                    <div className="container-fluid">
                        <a className="navbar-brand">Notes List</a>
                    </div>
                </nav>
            </div>
            <div className='row' style={{ padding: "5px 10px" }}>
                <div className='col-md-3'>

                    <div className='mainGetData'>
                        <h3>THIS</h3>
                        <ul className='listGetData'  >

                            <li>
                                <span className='noteGet'>
                                    <ArrowRightCircleFill size={15} style={{ marginRight: '5px' }} />
                                    NEW
                                </span>
                                <span className='amountGet' > 67</span><hr />
                            </li>

                            <li>
                                <span className='noteGet'>
                                    <ArrowRightCircleFill size={15} style={{ marginRight: '5px' }} />
                                    NEW
                                </span>
                                <span className='amountGet' > 67</span><hr />
                            </li>

                            <li>
                                <span className='noteGet'>
                                    <ArrowRightCircleFill size={15} style={{ marginRight: '5px' }} />
                                    NEW
                                </span>
                                <span className='amountGet' > 67</span><hr />
                            </li>
                            
                           

                        </ul>
                        <div style={{ textAlign: "right", marginRight: '5%', paddingBottom: '5%' }}>
                            <TrashFill size={22} style={{
                                color: "hsl(25, 87%, 56%) ",
                                cursor: "pointer"

                            }} />

                            <PencilSquare size={22} style={{
                                color: "hsl(25, 87%, 56%) ",
                                marginLeft:"2%",
                                cursor: "pointer"
                            }} />
                        </div>
                    </div>
                </div>
            </div>
            <div className='add-Note'>
                <PlusLg
                    style={{ color: "white", fontSize: '30px', fontWeight: 'bold' }}
                    onClick={() => navigate('/addNote')}
                />
            </div>
        </>

    )
}
